I choose RRT as the solution to the motion planning problem.

the code directory contains the project code using Python.

the result directory contains the csv file. Specifically, edges��nodes and path.csv output by the code.

the png file is the screenshot of my solution path displayed in CoppeliaSim software.